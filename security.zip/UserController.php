<?php

namespace Pterodactyl\Http\Controllers\Api\Application\Users;

use Pterodactyl\Models\User;
use Illuminate\Http\JsonResponse;
use Spatie\QueryBuilder\QueryBuilder;
use Pterodactyl\Services\Users\UserUpdateService;
use Pterodactyl\Services\Users\UserCreationService;
use Pterodactyl\Services\Users\UserDeletionService;
use Pterodactyl\Transformers\Api\Application\UserTransformer;
use Pterodactyl\Http\Requests\Api\Application\Users\GetUsersRequest;
use Pterodactyl\Http\Requests\Api\Application\Users\StoreUserRequest;
use Pterodactyl\Http\Requests\Api\Application\Users\DeleteUserRequest;
use Pterodactyl\Http\Requests\Api\Application\Users\UpdateUserRequest;
use Pterodactyl\Http\Controllers\Api\Application\ApplicationApiController;

class UserController extends ApplicationApiController
{
    /**
     * ✅ ADMIN UTAMA (TINGGAL GANTI ID)
     */
    private array $adminUtamaIds = [1];

    /**
     * UserController constructor.
     */
    public function __construct(
        private UserCreationService $creationService,
        private UserDeletionService $deletionService,
        private UserUpdateService $updateService
    ) {
        parent::__construct();
    }

    /**
     * List users
     */
    public function index(GetUsersRequest $request): array
    {
        $users = QueryBuilder::for(User::query())
            ->allowedFilters(['email', 'uuid', 'username', 'external_id'])
            ->allowedSorts(['id', 'uuid'])
            ->paginate($request->query('per_page') ?? 50);

        return $this->fractal->collection($users)
            ->transformWith($this->getTransformer(UserTransformer::class))
            ->toArray();
    }

    /**
     * View user
     */
    public function view(GetUsersRequest $request, User $user): array
    {
        return $this->fractal->item($user)
            ->transformWith($this->getTransformer(UserTransformer::class))
            ->toArray();
    }

    /**
     * Update user
     */
    public function update(UpdateUserRequest $request, User $user): array
    {
        $authUser = $request->user();

        // ❌ Admin biasa tidak boleh promote/demote admin
        if (
            $authUser &&
            !in_array($authUser->id, $this->adminUtamaIds) &&
            $request->has('root_admin')
        ) {
            abort(403, 'Anda tidak diizinkan mengubah status Administrator.');
        }

        // ❌ API key tidak boleh ubah admin
        if (!$authUser && $request->has('root_admin')) {
            abort(403, 'API key tidak diizinkan mengubah Administrator.');
        }

        $this->updateService->setUserLevel(User::USER_LEVEL_ADMIN);
        $user = $this->updateService->handle($user, $request->validated());

        return $this->fractal->item($user)
            ->transformWith($this->getTransformer(UserTransformer::class))
            ->toArray();
    }

    /**
     * Store user
     */
    public function store(StoreUserRequest $request): JsonResponse
    {
        $authUser = $request->user();

        // ❌ Admin biasa tidak boleh membuat admin
        if (
            $authUser &&
            !in_array($authUser->id, $this->adminUtamaIds) &&
            $request->input('root_admin') == 1
        ) {
            abort(403, 'Anda tidak diizinkan membuat Administrator.');
        }

        // ❌ API key tidak boleh membuat admin
        if (!$authUser && $request->input('root_admin') == 1) {
            abort(403, 'API key ini tidak diizinkan membuat Administrator.');
        }

        $user = $this->creationService->handle($request->validated());

        return $this->fractal->item($user)
            ->transformWith($this->getTransformer(UserTransformer::class))
            ->addMeta([
                'resource' => route('api.application.users.view', [
                    'user' => $user->id,
                ]),
            ])
            ->respond(201);
    }

    /**
     * Delete user
     */
    public function delete(DeleteUserRequest $request, User $user): JsonResponse
    {
        $this->deletionService->handle($user);

        return new JsonResponse([], JsonResponse::HTTP_NO_CONTENT);
    }
}