<?php

namespace Pterodactyl\Http\Controllers\Api\Application\Servers;

use Illuminate\Http\Response;
use Pterodactyl\Models\Server;
use Pterodactyl\Models\User;
use Illuminate\Http\JsonResponse;
use Spatie\QueryBuilder\QueryBuilder;
use Pterodactyl\Services\Servers\ServerCreationService;
use Pterodactyl\Services\Servers\ServerDeletionService;
use Pterodactyl\Transformers\Api\Application\ServerTransformer;
use Pterodactyl\Http\Requests\Api\Application\Servers\GetServerRequest;
use Pterodactyl\Http\Requests\Api\Application\Servers\GetServersRequest;
use Pterodactyl\Http\Requests\Api\Application\Servers\ServerWriteRequest;
use Pterodactyl\Http\Requests\Api\Application\Servers\StoreServerRequest;
use Pterodactyl\Http\Controllers\Api\Application\ApplicationApiController;

class ServerController extends ApplicationApiController
{
    // ID admin utama (sesuaikan)
    private array $adminUtamaIds = [1];

    public function __construct(
        private ServerCreationService $creationService,
        private ServerDeletionService $deletionService
    ) {
        parent::__construct();
    }

    /**
     * Ambil user dari API key.
     */
    private function currentUser(): ?User
    {
        // API keys memiliki kolom user_id → ambil manual
        $key = $this->request->attributes->get('api_key');
        if ($key && $key->user_id) {
            return User::find($key->user_id);
        }
        return auth()->user();
    }

    private function isAdminUtama(?User $user): bool
    {
        return $user && in_array($user->id, $this->adminUtamaIds);
    }

    public function index(GetServersRequest $request): array|JsonResponse
    {
        /*$user = $this->currentUser();
        if (!$this->isAdminUtama($user)) {
            return response()->json(['error' => 'Hanya admin utama yang diizinkan.'], 403);
        }*/

        $servers = QueryBuilder::for(Server::query())
            ->allowedFilters(['uuid', 'uuidShort', 'name', 'description', 'image', 'external_id'])
            ->allowedSorts(['id', 'uuid'])
            ->paginate($request->query('per_page') ?? 50);

        return $this->fractal->collection($servers)
            ->transformWith($this->getTransformer(ServerTransformer::class))
            ->toArray();
    }

    public function view(GetServerRequest $request, Server $server): array|JsonResponse
    {
        $user = $this->currentUser();
        if (!$this->isAdminUtama($user)) {
            return response()->json(['error' => 'Hanya admin utama yang diizinkan.'], 403);
        }

        return $this->fractal->item($server)
            ->transformWith($this->getTransformer(ServerTransformer::class))
            ->toArray();
    }

    public function delete(ServerWriteRequest $request, Server $server, string $force = ''): Response|JsonResponse
    {
        $user = $this->currentUser();
        if (!$this->isAdminUtama($user)) {
            return response()->json(['error' => 'Hanya admin utama yang dapat menghapus server.'], 403);
        }

        $this->deletionService->withForce($force === 'force')->handle($server);
        return $this->returnNoContent();
    }

    public function store(StoreServerRequest $request): JsonResponse
    {
        /*$user = $this->currentUser();
        if (!$this->isAdminUtama($user)) {
            return response()->json(['error' => 'Hanya admin utama yang diizinkan.'], 403);
        }*/

        $server = $this->creationService->handle($request->validated(), $request->getDeploymentObject());

        return $this->fractal->item($server)
            ->transformWith($this->getTransformer(ServerTransformer::class))
            ->respond(201);
    }
}