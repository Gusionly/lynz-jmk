@extends('layouts.admin')

@section('title')
    Manager User: {{ $user->username }}
@endsection

@php
    // ✅ ADMIN UTAMA (TINGGAL GANTI ID)
    $adminUtamaIds = [1];
@endphp

@section('content-header')
    <h1>{{ $user->name_first }} {{ $user->name_last}}<small>{{ $user->username }}</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('admin.index') }}">Admin</a></li>
        <li><a href="{{ route('admin.users') }}">Users</a></li>
        <li class="active">{{ $user->username }}</li>
    </ol>
@endsection

@section('content')
<div class="row">
    <form action="{{ route('admin.users.view', $user->id) }}" method="post">
        <div class="col-md-6">
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title">Identity</h3>
                </div>
                <div class="box-body">

                    {{-- Email (✅ BISA DIUBAH) --}}
                    <div class="form-group">
                        <label for="email" class="control-label">Email</label>
                        <input type="email"
                               name="email"
                               value="{{ old('email', $user->email) }}"
                               class="form-control form-autocomplete-stop">
                        @error('email')
                            <span class="text-danger"><small>{{ $message }}</small></span>
                        @enderror
                    </div>

                    {{-- Username --}}
                    <div class="form-group">
                        <label for="registered" class="control-label">Username</label>
                        <input type="text"
                               name="username"
                               value="{{ old('username', $user->username) }}"
                               class="form-control form-autocomplete-stop"
                               @if(!in_array(auth()->user()->id, $adminUtamaIds)) disabled @endif>
                        @error('username')
                            <span class="text-danger"><small>{{ $message }}</small></span>
                        @enderror
                    </div>

                    {{-- First Name --}}
                    <div class="form-group">
                        <label for="registered" class="control-label">Client First Name</label>
                        <input type="text"
                               name="name_first"
                               value="{{ old('name_first', $user->name_first) }}"
                               class="form-control form-autocomplete-stop">
                        @error('name_first')
                            <span class="text-danger"><small>{{ $message }}</small></span>
                        @enderror
                    </div>

                    {{-- Last Name --}}
                    <div class="form-group">
                        <label for="registered" class="control-label">Client Last Name</label>
                        <input type="text"
                               name="name_last"
                               value="{{ old('name_last', $user->name_last) }}"
                               class="form-control form-autocomplete-stop">
                        @error('name_last')
                            <span class="text-danger"><small>{{ $message }}</small></span>
                        @enderror
                    </div>

                    {{-- Language --}}
                    <div class="form-group">
                        <label class="control-label">Default Language</label>
                        <select name="language" class="form-control">
                            @foreach($languages as $key => $value)
                                <option value="{{ $key }}" @if(old('language', $user->language) === $key) selected @endif>
                                    {{ $value }}
                                </option>
                            @endforeach
                        </select>
                        @error('language')
                            <span class="text-danger"><small>{{ $message }}</small></span>
                        @enderror
                        <p class="text-muted">
                            <small>The default language to use when rendering the Panel for this user.</small>
                        </p>
                    </div>
                </div>

                <div class="box-footer">
                    {!! csrf_field() !!}
                    {!! method_field('PATCH') !!}
                    <input type="submit" value="Update User" class="btn btn-primary btn-sm">
                </div>
            </div>
        </div>

        {{-- Password --}}
        <div class="col-md-6">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Password</h3>
                </div>
                <div class="box-body">
                    <div class="alert alert-success" style="display:none;margin-bottom:10px;" id="gen_pass"></div>
                    <div class="form-group no-margin-bottom">
                        <label for="password" class="control-label">Password</label>
                        <input type="password"
                               id="password"
                               name="password"
                               class="form-control form-autocomplete-stop"
                               @if(!in_array(auth()->user()->id, $adminUtamaIds)) disabled @endif>
                        @error('password')
                            <span class="text-danger"><small>{{ $message }}</small></span>
                        @enderror
                        <p class="text-muted small">
                            Leave blank to keep this user's password the same.
                        </p>
                    </div>
                </div>
            </div>
        </div>

        {{-- Permissions --}}
        <div class="col-md-6">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Permissions</h3>
                </div>
                <div class="box-body">
                    <div class="form-group">
                        <label for="root_admin" class="control-label">Administrator</label>
                        <select name="root_admin"
                                class="form-control"
                                @if(!in_array(auth()->user()->id, $adminUtamaIds)) disabled @endif>
                            <option value="0" {{ old('root_admin', $user->root_admin) == 0 ? 'selected' : '' }}>
                                @lang('strings.no')
                            </option>
                            <option value="1" {{ old('root_admin', $user->root_admin) == 1 ? 'selected' : '' }}>
                                @lang('strings.yes')
                            </option>
                        </select>
                        @error('root_admin')
                            <span class="text-danger"><small>{{ $message }}</small></span>
                        @enderror
                        <p class="text-muted">
                            <small>Setting this to 'Yes' gives a user full administrative access.</small>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </form>

    {{-- Delete User --}}
    <div class="col-xs-12">
        <div class="box box-danger">
            <div class="box-header with-border">
                <h3 class="box-title">Delete User</h3>
            </div>
            <div class="box-body">
                <p class="no-margin">
                    There must be no servers associated with this account in order for it to be deleted.
                </p>
            </div>
            <div class="box-footer">
                <form action="{{ route('admin.users.view', $user->id) }}" method="POST">
                    {!! csrf_field() !!}
                    {!! method_field('DELETE') !!}
                    <input id="delete"
                           type="submit"
                           class="btn btn-sm btn-danger pull-right"
                           {{ (!in_array(auth()->user()->id, $adminUtamaIds) || $user->servers->count() >= 1) ? 'disabled' : '' }}
                           value="Delete User">
                </form>
            </div>
        </div>
    </div>
</div>
@endsection